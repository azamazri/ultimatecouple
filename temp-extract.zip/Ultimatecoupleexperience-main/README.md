
  # Landing Page Design Request

  This is a code bundle for Landing Page Design Request. The original project is available at https://www.figma.com/design/R3UPziKGB0oiOwJoFibHQx/Landing-Page-Design-Request.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  