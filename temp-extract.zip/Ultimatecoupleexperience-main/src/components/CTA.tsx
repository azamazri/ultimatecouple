import { MessageCircle, Heart, Clock, Users } from 'lucide-react';

export function CTA() {
  const whatsappNumber = "6281234567890"; // Ganti dengan nomor WhatsApp yang sesuai
  const message = encodeURIComponent("Halo, saya tertarik untuk mendaftar Ultimate Couple Experience. Mohon info lebih lanjut.");
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${message}`;

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-[#184C38] to-[#0f3326] relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 border-4 border-[#D7A753] rounded-full"></div>
        <div className="absolute bottom-20 right-10 w-48 h-48 border-4 border-[#D7A753] rounded-full"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 border-4 border-[#D7A753] rounded-full"></div>
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Heart className="w-8 h-8 text-[#D7A753] animate-pulse" />
            <h2 className="text-[#D7A753] text-4xl md:text-5xl font-bold">
              Saatnya Merawat Cinta Kalian
            </h2>
            <Heart className="w-8 h-8 text-[#D7A753] animate-pulse" />
          </div>
          <p className="text-[#F1E7D0] text-xl max-w-2xl mx-auto">
            Jangan lewatkan kesempatan untuk menguatkan ikatan dan menemukan kebahagiaan baru bersama pasangan
          </p>
        </div>

        {/* Urgency Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border-2 border-[#D7A753]">
            <div className="flex items-center gap-3 text-[#F1E7D0]">
              <Users className="w-6 h-6 text-[#D7A753]" />
              <div>
                <p className="text-sm opacity-80">Kuota Tersisa</p>
                <p className="text-[#D7A753] text-xl">Hanya 20 Pasangan</p>
              </div>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border-2 border-[#D7A753]">
            <div className="flex items-center gap-3 text-[#F1E7D0]">
              <Clock className="w-6 h-6 text-[#D7A753]" />
              <div>
                <p className="text-sm opacity-80">Tanggal Event</p>
                <p className="text-[#D7A753] text-xl">22-23 Nov 2025</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main CTA Button */}
        <div className="text-center">
          <a 
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-4 bg-gradient-to-r from-orange-500 via-orange-600 to-[#D7A753] text-white px-12 py-6 rounded-full text-xl hover:from-orange-600 hover:via-orange-700 hover:to-[#c99942] transition-all duration-300 shadow-2xl hover:shadow-3xl transform hover:scale-105 border-4 border-white/20"
          >
            <MessageCircle className="w-8 h-8" />
            <span className="tracking-wide">DAFTAR SEKARANG</span>
            <MessageCircle className="w-8 h-8" />
          </a>
          
          <p className="text-[#F1E7D0] mt-6 text-sm">
            Klik tombol di atas untuk menghubungi kami via WhatsApp
          </p>
        </div>

        {/* Trust Badges */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="bg-[#D7A753] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
              <Heart className="w-8 h-8 text-[#184C38]" />
            </div>
            <p className="text-[#F1E7D0]">Garansi 100%</p>
          </div>
          <div className="text-center">
            <div className="bg-[#D7A753] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
              <Users className="w-8 h-8 text-[#184C38]" />
            </div>
            <p className="text-[#F1E7D0]">Eksklusif & Personal</p>
          </div>
          <div className="text-center">
            <div className="bg-[#D7A753] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
              <MessageCircle className="w-8 h-8 text-[#184C38]" />
            </div>
            <p className="text-[#F1E7D0]">Pendaftaran Mudah</p>
          </div>
        </div>
      </div>
    </section>
  );
}
